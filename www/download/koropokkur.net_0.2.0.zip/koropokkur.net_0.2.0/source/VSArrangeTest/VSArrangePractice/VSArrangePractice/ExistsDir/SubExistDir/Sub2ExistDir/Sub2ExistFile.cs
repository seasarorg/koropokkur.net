﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibrary1.DeletedDir.SubDeletedDir.Sub2DeletedDir
{
    class Sub2ExistFile
    {
    }
}
