﻿#region Copyright
/*
 * Copyright 2005-2009 the Seasar Foundation and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
#endregion

using System.Collections.Generic;

namespace VSArrange.Config
{
    /// <summary>
    /// 設定情報クラス
    /// </summary>
    public class ConfigInfo
    {
        #region for Singleton
        private static ConfigInfo _configInfo = null;

        public static ConfigInfo GetInstance()
        {
            if(_configInfo == null)
            {
                _configInfo = new ConfigInfo();
            }
            return _configInfo;
        }

        /// <summary>
        /// シングルトン用コンストラクタ
        /// </summary>
        private ConfigInfo()
        {
        }

        #endregion

        private IList<ConfigInfoFilter> _filterFileStringList;

        /// <summary>
        /// ファイル名用フィルター文字列リスト
        /// </summary>
        public IList<ConfigInfoFilter> FilterFileStringList
        {
            set { _filterFileStringList = value; }
            get { return _filterFileStringList; }
        }

        private IList<ConfigInfoFilter> _filterFolderStringList;

        /// <summary>
        /// フォルダ名用フィルター文字列リスト
        /// </summary>
        public IList<ConfigInfoFilter> FilterFolderStringList
        {
            set { _filterFolderStringList = value; }
            get { return _filterFolderStringList; }
        }
    }
}
