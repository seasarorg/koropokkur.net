using System.Reflection;
using System.Runtime.CompilerServices;

//
// アセンブリに関する一般情報は以下の属性セットをとおして制御されます。 
// アセンブリに関連付けられている情報を変更するには、
// これらの属性値を変更してください。
//
[assembly: AssemblyTitle("CopyGen")]
[assembly: AssemblyDescription("コピー処理を自動生成するアドイン")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("Copyright 2005-2010 the Seasar Foundation and the Others.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

//
// アセンブリのバージョン情報は、以下の 4 つの値で構成されています:
//
//      Major Version
//      Minor Version 
//      Revision
//      Build Number
//
// すべての値を指定するか、下のように '*' を使ってリビジョンおよびビルド番号を 
// 既定値にすることができます:

[assembly: AssemblyVersion("0.2.3.0")]

//
// アセンブリに署名するには、使用するキーを指定しなければなりません。アセンブリ署名に関する 
// 詳細については、Microsoft .NET Framework ドキュメントを参照してください。
//
// 下の属性を使用して、署名に使用されるキーを制御します。 
//
// メモ: 
//   (*) キーが指定されないと、アセンブリは署名されません。
//   (*) KeyName は、コンピュータにインストールされている暗号サービス プロバイダ (CSP) を
//       表します。 
//   (*) キー ファイルおよびキー名の属性が共に指定されている場合は、 
//       以下の処理が行われます:
//       (1) KeyName が CSP に見つかった場合、そのキーが使われます。
//       (2) KeyName が存在せず、KeyFile が存在する場合、 
//           ファイルにあるキーが CSP にインストールされ、使われます。
//   (*) 遅延署名は高度なオプションです - Microsoft .NET Framework
//       ドキュメントを参照してください。
//
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]
[assembly: AssemblyFileVersionAttribute("0.2.3.0")]
