﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DummyProject4VSArrangeTest.Remove.Hoge
{
    class Class1
    {
    }
}
