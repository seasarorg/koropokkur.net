﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DummyProject4VSArrangeTest.Attribute
{
    /// <summary>
    /// VSArrange実行後「ビルドアクション」が「埋め込みリソース」→「コンパイル」に
    /// なっていることを想定しているクラス
    /// </summary>
    class ResourceToCompile
    {
    }
}
